# مؤقتات الدقايق - تحويل لـ APK

## الخطوات
1. ثبّت Node.js (نسخة LTS) و Android Studio.
2. افتح الفولدر ده في التيرمنال واكتب: `npm install`
3. اكتب: `npx cap add android`
4. اكتب: `npx cap sync android`
5. اكتب: `npx cap open android` (هيفتح Android Studio)
6. من Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s)
7. الملف هيكون في: `android/app/build/outputs/apk/debug/app-debug.apk`
8. انقل الملف للتليفون وثبّته (لازم تفعّل "تثبيت من مصادر غير معروفة").

## بعد التثبيت
- اسمح للتطبيق بالإشعارات.
- على شاومي / هواوي / أوبو: استثني التطبيق من توفير البطارية، عشان المنبه يوصل في وقته.

## ملاحظات
- التنبيهات بتتجدول على مستوى النظام، فبتوصل حتى لو التطبيق مقفول.
- الـ `appId` في `capacitor.config.json` لازم يكون فريد، غيّر `com.example.timers` لاسمك لو هتنزله على Play Store.

## الكود الأصلي (ويدجت + منبه بشاشة كاملة)
بعد الخطوة 4 (`npx cap sync android`):
1. انسخ محتوى `native-android/java/com/example/timers/` لـ `android/app/src/main/java/com/example/timers/` وخلّي `MainActivity.java` يستبدل الموجود.
2. انسخ `native-android/res/layout/` و `native-android/res/xml/` لـ `android/app/src/main/res/`.
3. افتح `native-android/AndroidManifest-snippet.xml` واتبع الخطوتين اللي فيه جوه `android/app/src/main/AndroidManifest.xml`.
4. تأكد إن `package` في الكود (`com.example.timers`) هو نفس الـ `appId` في `capacitor.config.json`، ولو غيّرته غيّره في كل ملفات Java كمان.
5. ابني الـ APK تاني من Android Studio.

## إزاي بيشتغل
- المنبه بيتسجل عند النظام (AlarmManager)، فبيفضل شغال حتى لو التطبيق مقفول.
- لما يخلص التايمر: إشعار بشاشة كاملة + صوت منبه، والشاشة بتضيء وتظهر فوق شاشة القفل.
- الويدجت بيتحدّث لما تفتح التطبيق، وبيتحدّث تلقائي كل 30 دقيقة.
- بعد إعادة تشغيل التليفون، افتح التطبيق مرة عشان المنبهات تتجدول تاني.
