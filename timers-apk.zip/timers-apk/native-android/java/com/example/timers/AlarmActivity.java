package com.example.timers;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.Context;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

public class AlarmActivity extends Activity {
  private Ringtone ringtone;
  private int timerId;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    // تظهر فوق شاشة القفل وتشغّل الشاشة
    if (Build.VERSION.SDK_INT >= 27) {
      setShowWhenLocked(true);
      setTurnScreenOn(true);
    } else {
      getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
          | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
    }
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    setContentView(R.layout.activity_alarm);

    timerId = getIntent().getIntExtra("id", 0);
    String name = getIntent().getStringExtra("name");
    ((TextView) findViewById(R.id.alarm_name)).setText(name == null ? "تايمر" : name);

    Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
    ringtone = RingtoneManager.getRingtone(this, uri);
    if (ringtone != null) {
      if (Build.VERSION.SDK_INT >= 28) ringtone.setLooping(true);
      ringtone.play();
    }

    ((Button) findViewById(R.id.dismiss)).setOnClickListener(v -> {
      stopAlarm();
      finish();
    });
  }

  private void stopAlarm() {
    if (ringtone != null && ringtone.isPlaying()) ringtone.stop();
    NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
    nm.cancel(1000 + timerId);
  }

  @Override
  protected void onDestroy() {
    stopAlarm();
    super.onDestroy();
  }
}
