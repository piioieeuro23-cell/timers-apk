package com.example.timers;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class TimerAlarmReceiver extends BroadcastReceiver {
  public static final String CHANNEL_ID = "timer_alarm";

  @Override
  public void onReceive(Context ctx, Intent intent) {
    int id = intent.getIntExtra("id", 0);
    String name = intent.getStringExtra("name");
    if (name == null) name = "تايمر";

    NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
    if (Build.VERSION.SDK_INT >= 26) {
      NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "المنبهات", NotificationManager.IMPORTANCE_HIGH);
      ch.enableVibration(true);
      nm.createNotificationChannel(ch);
    }

    Intent full = new Intent(ctx, AlarmActivity.class);
    full.putExtra("id", id);
    full.putExtra("name", name);
    full.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    PendingIntent fullPi = PendingIntent.getActivity(ctx, id, full,
        PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

    Notification.Builder b = Build.VERSION.SDK_INT >= 26
        ? new Notification.Builder(ctx, CHANNEL_ID)
        : new Notification.Builder(ctx);
    b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
        .setContentTitle("⏰ خلص التايمر")
        .setContentText(name)
        .setCategory(Notification.CATEGORY_ALARM)
        .setPriority(Notification.PRIORITY_MAX)
        .setFullScreenIntent(fullPi, true)
        .setContentIntent(fullPi)
        .setAutoCancel(true);

    nm.notify(1000 + id, b.build());
  }
}
