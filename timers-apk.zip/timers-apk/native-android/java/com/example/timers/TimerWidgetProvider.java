package com.example.timers;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class TimerWidgetProvider extends AppWidgetProvider {

  @Override
  public void onUpdate(Context ctx, AppWidgetManager mgr, int[] ids) {
    String json = ctx.getSharedPreferences("timers_widget", Context.MODE_PRIVATE)
        .getString("snapshot", "[]");
    int running = 0;
    String nextName = null;
    long nextEnd = Long.MAX_VALUE;
    long now = System.currentTimeMillis();
    try {
      JSONArray arr = new JSONArray(json);
      for (int i = 0; i < arr.length(); i++) {
        JSONObject o = arr.getJSONObject(i);
        String st = o.optString("status");
        if ("running".equals(st) || "scheduled".equals(st)) running++;
        if ("running".equals(st)) {
          long e = o.optLong("endAt", 0);
          if (e > now && e < nextEnd) {
            nextEnd = e;
            nextName = o.optString("name");
          }
        }
      }
    } catch (Exception ignored) {}

    Intent launch = ctx.getPackageManager().getLaunchIntentForPackage(ctx.getPackageName());
    PendingIntent openApp = PendingIntent.getActivity(ctx, 0, launch,
        PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

    for (int id : ids) {
      RemoteViews v = new RemoteViews(ctx.getPackageName(), R.layout.widget_timer);
      v.setTextViewText(R.id.w_count, running + " شغال");
      if (nextName != null) {
        v.setTextViewText(R.id.w_next, nextName);
        v.setTextViewText(R.id.w_time, new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date(nextEnd)));
      } else {
        v.setTextViewText(R.id.w_next, "مفيش تايمر شغال");
        v.setTextViewText(R.id.w_time, "");
      }
      v.setOnClickPendingIntent(R.id.w_root, openApp);
      mgr.updateAppWidget(id, v);
    }
  }
}
