package com.example.timers;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "TimerBridge")
public class TimerBridgePlugin extends Plugin {

  @PluginMethod
  public void scheduleAlarm(PluginCall call) {
    int id = call.getInt("id", 0);
    String name = call.getString("name", "تايمر");
    long at = (long) call.getDouble("at", 0d);
    Context ctx = getContext();
    AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);

    Intent alarm = new Intent(ctx, TimerAlarmReceiver.class);
    alarm.putExtra("id", id);
    alarm.putExtra("name", name);
    PendingIntent op = PendingIntent.getBroadcast(ctx, id, alarm,
        PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

    Intent show = new Intent(ctx, MainActivity.class);
    PendingIntent showIntent = PendingIntent.getActivity(ctx, id, show,
        PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

    // setAlarmClock بيدي دقة عالية ومش محتاج صلاحية إضافية، وبيظهر أيقونة المنبه في الشريط
    am.setAlarmClock(new AlarmManager.AlarmClockInfo(at, showIntent), op);
    call.resolve();
  }

  @PluginMethod
  public void cancelAlarm(PluginCall call) {
    int id = call.getInt("id", 0);
    Context ctx = getContext();
    AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
    Intent alarm = new Intent(ctx, TimerAlarmReceiver.class);
    PendingIntent p = PendingIntent.getBroadcast(ctx, id, alarm,
        PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
    if (p != null) {
      am.cancel(p);
      p.cancel();
    }
    call.resolve();
  }

  @PluginMethod
  public void saveSnapshot(PluginCall call) {
    String json = call.getString("json", "[]");
    Context ctx = getContext();
    ctx.getSharedPreferences("timers_widget", Context.MODE_PRIVATE)
        .edit().putString("snapshot", json).apply();

    AppWidgetManager mgr = AppWidgetManager.getInstance(ctx);
    int[] ids = mgr.getAppWidgetIds(new ComponentName(ctx, TimerWidgetProvider.class));
    if (ids != null && ids.length > 0) {
      Intent i = new Intent(ctx, TimerWidgetProvider.class);
      i.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
      i.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, ids);
      ctx.sendBroadcast(i);
    }
    call.resolve();
  }
}
